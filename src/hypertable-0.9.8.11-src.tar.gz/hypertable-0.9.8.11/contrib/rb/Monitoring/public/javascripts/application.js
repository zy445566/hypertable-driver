//js autoupdate
$(document).ready(function() { 
  // $('#graph_form').ajaxForm({dataType: 'script'}); 

	// //for jqueryForm plugin
	// var options = {
	// 	success: showResponse,  // post-submit callback
	// 	dataType:  'json'        // 'xml', 'script', or 'json' (expected server response type)    
	// }
  // bind to the form's submit event 
	//   $('#graph_form').submit(function() { 
	//       // inside event callbacks 'this' is the DOM element so we first 
	//       // wrap it in a jQuery object and then invoke ajaxSubmit 
	// 		alert("in here")
	//       $(this).ajaxSubmit(options); 
	//       // always return false to prevent standard browser submit and page navigation 
	//       return false; 
	//   });
	// 
	// function showResponse(responseText, statusText, xhr, $form) {
	// 	alert("in here too?")
	// 	
	// 	alert(responseText);
	// }
});





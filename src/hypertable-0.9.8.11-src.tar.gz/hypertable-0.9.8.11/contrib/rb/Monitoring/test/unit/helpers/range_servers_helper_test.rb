require 'test_helper'

class RangeServersHelperTest < ActionView::TestCase
end

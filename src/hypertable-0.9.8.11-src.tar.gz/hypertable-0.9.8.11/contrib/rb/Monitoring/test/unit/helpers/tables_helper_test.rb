require 'test_helper'

class TablesHelperTest < ActionView::TestCase
end

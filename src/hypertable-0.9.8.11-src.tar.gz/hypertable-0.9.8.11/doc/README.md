For latest documentation, please see [the official documentation
page](http://www.hypertable.com/documentation)

To generate C++ source documentation, Thrift API reference and HQL reference,
Type the follow in the build tree:

    make doc

To generate HQL documentation only:

    make hqldoc

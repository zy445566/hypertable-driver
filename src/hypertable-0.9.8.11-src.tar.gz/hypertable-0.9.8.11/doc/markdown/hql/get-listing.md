GET LISTING
-----------
#### EBNF

    GET LISTING 

#### Description
<p>
The `GET LISTING` command lists the tables and namespaces in the current namespace 

#### Example

    hypertable> GET LISTING;
    foo
    sys   (namespace)
    Test

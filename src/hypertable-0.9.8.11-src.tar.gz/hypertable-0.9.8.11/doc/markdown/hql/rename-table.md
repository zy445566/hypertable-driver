RENAME TABLE
----------
#### EBNF

    RENAME TABLE table_name TO new_table_name

#### Description
<p>
The `RENAME TABLE` command renames the existing 'table\_name' to the 'new\_table\_name'.

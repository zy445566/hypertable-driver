SHOW TABLES
-----------
#### EBNF

    SHOW TABLES

#### Description
<p>
The `SHOW TABLES` command lists only the tables in the current namespace 

#### Example

    hypertable> SHOW TABLES;
    foo
    Test 

Hypertable Documentation
------------------------

[HQL Reference](hql/index.html) This document describes the Hypertable Query Language (HQL).  For each command it provides the BNF, describes how it is used, and gives working examples.

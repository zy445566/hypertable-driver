
Please visit https://github.com/cruppstahl/hypertable/wiki/Setup-PHP-microblog-sample for instructions.

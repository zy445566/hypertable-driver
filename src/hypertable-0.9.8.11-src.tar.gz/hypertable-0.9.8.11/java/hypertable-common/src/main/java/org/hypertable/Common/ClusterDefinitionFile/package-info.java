/**
 * Classes used for parsing a cluster definition file (<code>cluster.def</code>).
 */
package org.hypertable.Common.ClusterDefinitionFile;

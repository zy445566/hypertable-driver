/**
 * Common utility classes.
 */
package org.hypertable.Common;
